export const CUSTOM_REPORT_COLUMN_PREFIX = 'cf_';
const KEY_RE = /^[a-z][a-z0-9_]{0,62}$/;
const IDENT_RE = /^[a-z_][a-z0-9_]*$/i;
function customColumnKind(fieldType) {
    if (fieldType === 'number')
        return 'number';
    if (fieldType === 'date')
        return 'date';
    if (fieldType === 'datetime')
        return 'timestamp';
    return 'text';
}
function metadataExpression(table, key, fieldType) {
    const text = `"${table}"."metadata"->'custom'->>'${key}'`;
    if (fieldType === 'number')
        return `(${text})::numeric`;
    if (fieldType === 'date')
        return `(${text})::date`;
    if (fieldType === 'datetime')
        return `(${text})::timestamptz`;
    if (fieldType === 'multi_select')
        return `(SELECT string_agg(value, ', ') FROM jsonb_array_elements_text(coalesce("${table}"."metadata"->'custom'->'${key}', '[]'::jsonb)) AS value)`;
    return `(${text})`;
}
/** Converts active custom-field definitions into safe synthetic report columns. */
export function buildCustomReportColumns(table, definitions) {
    if (!IDENT_RE.test(table))
        throw new Error('Custom report columns require a plain allowlisted table identifier');
    return definitions.filter((definition) => KEY_RE.test(definition.key)).map((definition) => ({
        key: `${CUSTOM_REPORT_COLUMN_PREFIX}${definition.key}`,
        label: definition.label,
        kind: customColumnKind(definition.fieldType),
        expression: metadataExpression(table, definition.key, definition.fieldType),
    }));
}
export async function augmentReportEntityWithCustomFields(entity, source) {
    const table = entity.table ?? entity.from;
    if (!table || !IDENT_RE.test(table))
        return entity;
    const columns = buildCustomReportColumns(table, await source.list(entity));
    const existing = new Set(entity.columns.map((column) => column.key));
    const added = columns.filter((column) => !existing.has(column.key));
    return added.length ? { ...entity, columns: [...entity.columns, ...added] } : entity;
}
export async function augmentReportCatalogWithCustomFields(entities, source) {
    return Promise.all(entities.map((entity) => augmentReportEntityWithCustomFields(entity, source)));
}
//# sourceMappingURL=custom-columns.js.map