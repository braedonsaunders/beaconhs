import type { ReportSchedule } from './types.js';
export declare function validateReportSchedule(schedule: ReportSchedule): string[];
export declare function computeNextReportRun(schedule: ReportSchedule, from?: Date): Date | null;
export declare function describeReportSchedule(schedule: Pick<ReportSchedule, 'cadence' | 'repeatEvery' | 'dayOfWeek' | 'dayOfMonth' | 'weekOfMonth' | 'hour' | 'minute' | 'timezone'>): string;
export declare function reportScheduleRecipientCount(schedule: Pick<ReportSchedule, 'recipientUserIds' | 'recipientEmails'>): number;
//# sourceMappingURL=schedule.d.ts.map