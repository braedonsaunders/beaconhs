import * as React from 'react';
import { type ParsedReportScheduleForm } from './schedule-form.js';
import type { ReportSchedule } from './types.js';
export type ReportScheduleDefinitionOption = {
    id: string;
    name: string;
    category?: string | null;
    kind?: 'built_in' | 'custom';
    description?: string | null;
};
export type ReportScheduleMemberOption = {
    userId: string;
    name: string;
    email: string;
};
export type ReportScheduleRun = {
    id: string;
    scheduleId: string;
    trigger: 'manual' | 'scheduled' | string;
    status: 'queued' | 'running' | 'succeeded' | 'failed' | string;
    error?: string | null;
    rowCount?: number | null;
    startedAt: string | Date;
    finishedAt?: string | Date | null;
    artifact?: {
        filename: string;
        sizeBytes: number;
        contentType: string;
        createdAt: string | Date;
        href?: string;
    } | null;
};
export type ReportScheduleFormProps = {
    definitions: ReportScheduleDefinitionOption[];
    members: ReportScheduleMemberOption[];
    initial?: Partial<ReportSchedule>;
    defaultTimezone?: string;
    submitLabel?: string;
    busy?: boolean;
    onSubmit: (value: ParsedReportScheduleForm) => void | Promise<void>;
    onCancel?: () => void;
    extraFooter?: React.ReactNode;
    className?: string;
};
/**
 * Complete create/edit schedule form extracted from the production reporting
 * surface. It posts through the same bounded parser as server adapters and
 * retains member recipients, external emails, nth-weekday cadence, date bounds,
 * delivery copy, days-window filtering, and advanced JSON filters.
 */
export declare function ReportScheduleForm({ definitions, members, initial, defaultTimezone, submitLabel, busy, onSubmit, onCancel, extraFooter, className }: ReportScheduleFormProps): React.JSX.Element;
export type ReportScheduleListProps = {
    schedules: ReportSchedule[];
    definitions?: ReportScheduleDefinitionOption[];
    query?: string;
    status?: 'all' | 'active' | 'paused';
    total?: number;
    page?: number;
    perPage?: number;
    canManage?: boolean;
    onQueryChange?: (query: string) => void;
    onStatusChange?: (status: 'all' | 'active' | 'paused') => void;
    onPageChange?: (page: number) => void;
    onCreate?: () => void;
    onOpen?: (schedule: ReportSchedule) => void;
    onToggle?: (schedule: ReportSchedule) => void | Promise<void>;
    onRun?: (schedule: ReportSchedule) => void | Promise<void>;
    onDelete?: (schedule: ReportSchedule) => void | Promise<void>;
};
/** Searchable, filterable, paged production schedule register. */
export declare function ReportScheduleList({ schedules, definitions, query, status, total, page, perPage, canManage, onQueryChange, onStatusChange, onPageChange, onCreate, onOpen, onToggle, onRun, onDelete }: ReportScheduleListProps): React.JSX.Element;
export type ReportRunHistoryProps = {
    runs: ReportScheduleRun[];
    total?: number;
    page?: number;
    perPage?: number;
    query?: string;
    status?: 'all' | 'queued' | 'running' | 'succeeded' | 'failed';
    onQueryChange?: (query: string) => void;
    onStatusChange?: (status: NonNullable<ReportRunHistoryProps['status']>) => void;
    onPageChange?: (page: number) => void;
    onOpen?: (run: ReportScheduleRun) => void;
    renderArtifactLink?: (run: ReportScheduleRun, content: React.ReactNode) => React.ReactNode;
};
/** Paged production run history with status/error/artifact fidelity. */
export declare function ReportRunHistory({ runs, total, page, perPage, query, status, onQueryChange, onStatusChange, onPageChange, onOpen, renderArtifactLink }: ReportRunHistoryProps): React.JSX.Element;
export declare function ReportRunDetail({ run, schedule, definitionName, onDownload }: {
    run: ReportScheduleRun;
    schedule: ReportSchedule;
    definitionName?: string;
    onDownload?: (run: ReportScheduleRun) => void;
}): React.JSX.Element;
//# sourceMappingURL=report-schedules.d.ts.map