import type { InsightQuery, SemanticType } from '@appkit/analytics';
export type ReportQuery = InsightQuery;
export type ReportColumn = {
    key: string;
    label: string;
    semanticType: SemanticType;
    align?: 'left' | 'center' | 'right';
};
export type ReportGroup = {
    kind: 'results' | 'section' | 'summary';
    title: string;
    subtitle?: string;
    columns: ReportColumn[];
    rows: Record<string, unknown>[];
    isEmpty?: boolean;
};
export type ReportSummaryItem = {
    key: string;
    label: string;
    value: string | number;
    semanticType?: SemanticType;
};
export type ReportRunResult = {
    groups: ReportGroup[];
    summary: ReportSummaryItem[];
    rowCount: number;
    truncated: boolean;
    durationMs: number;
};
export declare const REPORT_PAPER_SIZES: readonly ["letter", "a4", "legal"];
export type ReportPaperSize = (typeof REPORT_PAPER_SIZES)[number];
export declare const REPORT_DENSITIES: readonly ["standard", "compact"];
export type ReportDensity = (typeof REPORT_DENSITIES)[number];
export type ReportLayout = {
    paperSize: ReportPaperSize;
    orientation: 'portrait' | 'landscape';
    marginMm: number;
    showSummary: boolean;
    density: ReportDensity;
};
export declare const DEFAULT_REPORT_LAYOUT: ReportLayout;
export type ReportDefinition = {
    schemaVersion: 1;
    id: string;
    slug: string;
    name: string;
    description?: string;
    query: ReportQuery;
    layout: ReportLayout;
    state: 'draft' | 'published' | 'archived';
    tags?: string[];
};
export type ReportFormat = 'screen' | 'csv' | 'xlsx' | 'pdf';
export type ReportSchedule = {
    schemaVersion?: 1;
    id: string;
    definitionId: string;
    name: string;
    active: boolean;
    cadence: 'daily' | 'weekly' | 'monthly';
    timezone: string;
    hour: number;
    minute: number;
    dayOfWeek?: number | null;
    dayOfMonth?: number | null;
    weekOfMonth?: 1 | 2 | 3 | 4 | 5 | null;
    repeatEvery: number;
    startsOn?: string | null;
    endsOn?: string | null;
    recipientUserIds: string[];
    recipientEmails: string[];
    filters: Record<string, unknown>;
    emailSubject?: string | null;
    emailMessage?: string | null;
    nextRunAt?: string | Date | null;
    lastRunAt?: string | Date | null;
};
export declare function resolveReportLayout(value?: Partial<ReportLayout> | null): ReportLayout;
export declare function assertReportDefinition(value: ReportDefinition): void;
//# sourceMappingURL=types.d.ts.map