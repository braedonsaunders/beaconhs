import * as React from 'react';
export type ReportExportOption = {
    format: 'pdf' | 'xlsx' | 'csv';
    label: string;
    href?: string;
    onSelect?: () => void | Promise<void>;
};
export declare function printReportPdf(href: string): Promise<void>;
/** One compact report action containing print, PDF, spreadsheet, and CSV. */
export declare function ReportExportMenu({ options, printHref, label, printLabel, onError, }: {
    options: ReportExportOption[];
    printHref?: string;
    label?: string;
    printLabel?: string;
    onError?: (error: Error) => void;
}): React.JSX.Element;
//# sourceMappingURL=export-menu.d.ts.map