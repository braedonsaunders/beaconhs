'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Plus, Trash2 } from 'lucide-react';
import { Button, Input, Select } from '@appkit/ui';
import { operatorsForKind } from './filters.js';
import { PERIOD_PRESETS, PERIOD_PRESET_GROUP_LABELS } from './period-presets.js';
import { reportColumnOptions } from './entities.js';
const GROUP_ORDER = ['fiscal_year', 'fiscal_quarter', 'fiscal_half', 'period', 'calendar', 'rolling', 'days'];
function isGroup(node) { return 'rules' in node; }
/** Recursive nested and/or filter editor matching the tree consumed by the SQL compiler. */
export function ReportFilterTree({ entity, group, onChange, depth = 0 }) {
    const setRule = (index, rule) => { const rules = [...group.rules]; rules[index] = rule; onChange({ ...group, rules }); };
    const remove = (index) => onChange({ ...group, rules: group.rules.filter((_, current) => current !== index) });
    const addRule = () => {
        const column = entity.columns[0];
        if (column)
            onChange({ ...group, rules: [...group.rules, { field: column.key, op: operatorsForKind(column.kind)[0]?.key ?? 'eq', value: '' }] });
    };
    return _jsxs("div", { className: depth === 0 ? 'space-y-2 rounded-lg border border-border p-3' : 'space-y-2 rounded-lg border border-border bg-bg-subtle p-3', children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "text-xs text-fg-muted", children: "Match" }), _jsxs(Select, { className: "h-8 w-48", value: group.combinator, onChange: (event) => onChange({ ...group, combinator: event.target.value }), children: [_jsx("option", { value: "and", children: "all conditions" }), _jsx("option", { value: "or", children: "any condition" })] })] }), _jsxs("div", { className: "space-y-2", children: [group.rules.map((rule, index) => isGroup(rule) ? _jsx(ReportFilterTree, { entity: entity, group: rule, depth: depth + 1, onChange: (next) => setRule(index, next) }, index) : _jsx(RuleRow, { entity: entity, rule: rule, onChange: (next) => setRule(index, next), onRemove: () => remove(index) }, index)), group.rules.length === 0 ? _jsx("p", { className: "text-xs text-fg-subtle", children: "No conditions." }) : null] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: addRule, children: [_jsx(Plus, { size: 14 }), "Add condition"] }), depth < 3 ? _jsxs(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => onChange({ ...group, rules: [...group.rules, { combinator: 'and', rules: [] }] }), children: [_jsx(Plus, { size: 14 }), "Add group"] }) : null] })] });
}
function RuleRow({ entity, rule, onChange, onRemove }) {
    const column = entity.columns.find((item) => item.key === rule.field) ?? entity.columns[0];
    const operators = column ? operatorsForKind(column.kind) : [];
    const operator = operators.find((item) => item.key === rule.op) ?? operators[0];
    const options = column ? reportColumnOptions(column) : [];
    const changeField = (field) => {
        const nextColumn = entity.columns.find((item) => item.key === field);
        const available = nextColumn ? operatorsForKind(nextColumn.kind) : [];
        const nextOperator = available.some((item) => item.key === rule.op) ? rule.op : available[0]?.key ?? 'eq';
        onChange({ field, op: nextOperator, value: '' });
    };
    return _jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [_jsx(Select, { className: "h-8 min-w-40", value: rule.field, onChange: (event) => changeField(event.target.value), children: entity.columns.map((item) => _jsx("option", { value: item.key, children: item.label }, item.key)) }), _jsx(Select, { className: "h-8 min-w-36", value: rule.op, onChange: (event) => onChange({ ...rule, op: event.target.value }), children: operators.map((item) => _jsx("option", { value: item.key, children: item.label }, item.key)) }), rule.op === 'period_preset' ? _jsx(Select, { className: "h-8 w-52", value: typeof rule.value === 'string' ? rule.value : 'this_fiscal_year', onChange: (event) => onChange({ ...rule, value: event.target.value }), children: GROUP_ORDER.map((group) => _jsx("optgroup", { label: PERIOD_PRESET_GROUP_LABELS[group], children: PERIOD_PRESETS.filter((preset) => preset.group === group).map((preset) => _jsx("option", { value: preset.id, children: preset.label }, preset.id)) }, group)) })
                : operator?.needsValue === 'one' && options.length ? _jsxs(Select, { className: "h-8 w-44", value: typeof rule.value === 'string' ? rule.value : '', onChange: (event) => onChange({ ...rule, value: event.target.value }), children: [_jsx("option", { value: "", children: "Choose a value" }), options.map((option) => _jsx("option", { value: option.value, children: option.label }, option.value))] })
                    : operator?.needsValue === 'one' ? _jsx(Input, { className: "h-8 w-40", type: column?.kind === 'date' ? 'date' : column?.kind === 'number' ? 'number' : 'text', value: typeof rule.value === 'string' || typeof rule.value === 'number' ? String(rule.value) : '', placeholder: "Value", onChange: (event) => onChange({ ...rule, value: event.target.value }) })
                        : operator?.needsValue === 'list' && options.length ? _jsx("div", { className: "flex max-w-md flex-wrap gap-1", children: options.map((option) => { const selected = Array.isArray(rule.value) && rule.value.map(String).includes(option.value); return _jsx("button", { type: "button", onClick: () => { const current = Array.isArray(rule.value) ? rule.value.map(String) : []; onChange({ ...rule, value: selected ? current.filter((value) => value !== option.value) : [...current, option.value] }); }, className: selected ? 'rounded-full border border-primary bg-primary-subtle px-2 py-0.5 text-xs text-primary' : 'rounded-full border border-border px-2 py-0.5 text-xs text-fg-muted hover:border-border-strong', children: option.label }, option.value); }) })
                            : operator?.needsValue === 'list' ? _jsx(Input, { className: "h-8 w-52", value: Array.isArray(rule.value) ? rule.value.join(', ') : '', placeholder: "Comma-separated values", onChange: (event) => onChange({ ...rule, value: event.target.value.split(',').map((value) => value.trim()).filter(Boolean) }) })
                                : _jsx("span", { className: "text-xs text-fg-subtle", children: "No value" }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: onRemove, "aria-label": "Remove condition", children: _jsx(Trash2, { size: 14 }) })] });
}
//# sourceMappingURL=filter-tree.js.map