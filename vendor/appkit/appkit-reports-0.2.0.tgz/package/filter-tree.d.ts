import { type ReportRuleGroup } from './filters.js';
import { type ReportEntity } from './entities.js';
/** Recursive nested and/or filter editor matching the tree consumed by the SQL compiler. */
export declare function ReportFilterTree({ entity, group, onChange, depth }: {
    entity: ReportEntity;
    group: ReportRuleGroup;
    onChange: (group: ReportRuleGroup) => void;
    depth?: number;
}): import("react").JSX.Element;
//# sourceMappingURL=filter-tree.d.ts.map