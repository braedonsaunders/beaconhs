# @appkit/reports

Production report studio, governed query engine, paper and statement viewers, drill-through, exports, schedules, and durable runs.

## Install

```bash
pnpm add @appkit/reports
```

See the [AppKit documentation](https://github.com/braedonsaunders/appkit#readme) for package composition, optional adapters, and production guidance.
