export function reportEntity(catalog, key) {
    return catalog.entities.find((entity) => entity.key === key) ?? null;
}
export function reportColumn(entity, key) {
    return entity.columns.find((column) => column.key === key) ?? null;
}
export function reportColumnExpression(entity, key) {
    const column = reportColumn(entity, key);
    if (!column)
        return null;
    if (column.expression)
        return column.expression;
    if (column.expr)
        return column.expr;
    if (entity.table && IDENTIFIER.test(entity.table))
        return `"${entity.table}"."${column.sql ?? column.key}"`;
    return null;
}
const IDENTIFIER = /^[a-z_][a-z0-9_]*$/i;
export function reportEntityFrom(entity) {
    if (entity.from)
        return entity.from;
    if (entity.table && IDENTIFIER.test(entity.table))
        return `"${entity.table}"`;
    throw new Error(`Report entity "${entity.key}" does not define a safe source`);
}
export function reportTenantColumn(entity) {
    if (entity.tenantColumn)
        return entity.tenantColumn;
    if (entity.orgColumn)
        return entity.orgColumn;
    if (entity.table && IDENTIFIER.test(entity.table))
        return `"${entity.table}"."tenant_id"`;
    throw new Error(`Report entity "${entity.key}" does not define a tenant scope`);
}
export function defaultColumnsFor(entity, limit = 7) {
    if (entity.defaultColumns?.length)
        return entity.defaultColumns.filter((key) => Boolean(reportColumn(entity, key)));
    const operational = entity.columns.filter((column) => column.kind !== 'uuid' && column.key !== 'id' && column.key !== 'tenant_id' && column.key !== 'deleted_at');
    return (operational.length ? operational : entity.columns).slice(0, limit).map((column) => column.key);
}
export function reportColumnOptions(column) {
    if (column.enumOptions?.length)
        return column.enumOptions;
    return (column.options ?? []).map((value) => ({ value, label: value.replaceAll('_', ' ') }));
}
//# sourceMappingURL=entities.js.map