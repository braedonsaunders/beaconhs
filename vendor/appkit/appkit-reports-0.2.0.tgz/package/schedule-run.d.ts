export type ReportRunTrigger = 'scheduled' | 'manual';
export type ReportRunSnapshot<Definition = unknown, Filters = Record<string, unknown>> = {
    scheduleName: string;
    definition: Definition;
    filters: Filters;
    recipientUserIds: string[];
    recipientEmails: string[];
    emailSubject?: string | null;
    emailMessage?: string | null;
    runAsTenantUserId?: string | null;
    runAsRoleId?: string | null;
};
export type ReportScheduleRunContext<Definition = unknown, Filters = Record<string, unknown>> = {
    tenantId: string;
    scheduleId: string;
    scheduleName: string;
    definition: Definition;
    filters: Filters;
    recipientUserIds: readonly string[];
    recipientEmails: readonly string[];
    emailSubject?: string | null;
    emailMessage?: string | null;
    runAsTenantUserId?: string | null;
    runAsRoleId?: string | null;
};
export type ReportRunStore<Definition = unknown, Filters = Record<string, unknown>> = {
    loadContext(scheduleId: string): Promise<ReportScheduleRunContext<Definition, Filters> | null>;
    insert(input: {
        tenantId: string;
        scheduleId: string;
        scheduledFor: Date;
        trigger: ReportRunTrigger;
        requestSnapshot: ReportRunSnapshot<Definition, Filters>;
        status: 'queued';
    }): Promise<{
        id: string;
    } | null>;
    find(scheduleId: string, scheduledFor: Date): Promise<{
        id: string;
        trigger: ReportRunTrigger;
    } | null>;
};
export type ClaimedReportRun = {
    id: string;
    scheduledFor: Date;
    created: boolean;
};
/**
 * Creates the durable execution record before queue publication. Scheduled
 * occurrences are idempotent at (scheduleId, scheduledFor); manual requests
 * remain distinct even when requested in the same millisecond.
 */
export declare function claimReportRun<Definition = unknown, Filters = Record<string, unknown>>(store: ReportRunStore<Definition, Filters>, input: {
    scheduleId: string;
    scheduledFor: Date;
    trigger: ReportRunTrigger;
}): Promise<ClaimedReportRun>;
//# sourceMappingURL=schedule-run.d.ts.map