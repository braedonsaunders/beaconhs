import { type ReportEntityCatalog } from './entities.js';
import { type ReportRuleGroup } from './filters.js';
import type { ReportColumn, ReportRunResult } from './types.js';
export declare const REPORT_AGG_FNS: readonly ["count", "count_distinct", "sum", "avg", "min", "max"];
export type ReportAggFn = (typeof REPORT_AGG_FNS)[number];
export declare const REPORT_TEMPORAL_BINS: readonly ["day", "week", "month", "quarter", "year", "fiscal_period", "fiscal_quarter", "fiscal_year"];
export type ReportTemporalBin = (typeof REPORT_TEMPORAL_BINS)[number];
export type ReportBreakout = {
    column: string;
    bin?: ReportTemporalBin;
    label?: string;
};
export type ReportMeasure = {
    fn: ReportAggFn;
    column?: string;
    label?: string;
};
export type ReportCustomQuery = {
    entity: string;
    mode?: 'rows' | 'summarize';
    columns: string[];
    breakouts?: ReportBreakout[];
    measures?: ReportMeasure[];
    filters?: ReportRuleGroup | null;
    groupBy?: string | null;
    sort?: {
        column: string;
        direction: 'asc' | 'desc';
    } | null;
    sorts?: {
        column: string;
        direction: 'asc' | 'desc';
    }[] | null;
    columnLabels?: Record<string, string> | null;
    limit?: number | null;
};
export type CompiledCustomReport = {
    sql: string;
    params: unknown[];
    mode: 'rows' | 'summarize';
    columns: ReportColumn[];
    groupBy: string | null;
    limit: number;
};
export declare function compileCustomReport(query: ReportCustomQuery, tenantId: string, catalog: ReportEntityCatalog, options?: {
    maxRows?: number;
    fiscalStartMonth?: number;
}): CompiledCustomReport;
export declare function customReportResult(compiled: CompiledCustomReport, rows: Record<string, unknown>[], durationMs?: number): ReportRunResult;
//# sourceMappingURL=custom-query.d.ts.map