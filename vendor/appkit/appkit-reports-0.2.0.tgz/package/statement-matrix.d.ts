import * as React from 'react';
export type ReportScale = 'actual' | 'thousands' | 'millions';
export type StatementMatrixColumn = {
    key: string;
    label: string;
    group?: string;
    /** `variance_pct` is the production statement-engine value. `percentage`
     * remains accepted for application-authored catalogues. */
    kind?: 'amount' | 'number' | 'percentage' | 'variance_pct';
    [metadata: string]: unknown;
};
export type StatementMatrixLine = {
    key?: string;
    kind: 'section' | 'account' | 'subtotal' | 'total';
    label: string;
    number?: string;
    depth: number;
    emphasis?: boolean;
    values?: (number | undefined)[];
    /** Application-owned record identity and drill metadata. */
    accountId?: string;
    drillTypes?: string[];
    [metadata: string]: unknown;
};
export type StatementMatrixView = {
    columns: StatementMatrixColumn[];
    lines: StatementMatrixLine[];
    mode?: string;
};
export type StatementSectionVisibility = 'expand' | 'collapse';
export type StatementMatrixDrillContext = {
    line: StatementMatrixLine;
    column: StatementMatrixColumn;
    value: number;
    lineIndex: number;
    columnIndex: number;
    view: StatementMatrixView;
};
/**
 * The complete production statement surface: grouped column headings,
 * collapsible section/account hierarchies, scaling, accounting currency,
 * variance percentages, account links, total rules, and per-cell drill-through.
 * Domain-specific routes and drill target construction stay application-owned.
 */
export declare function StatementMatrixTable<TDrillTarget>({ view, scale, currency, locale, visibility, visibilityRevision, drillTarget, onDrill, onOpenRow, renderRowLink, formatValue, isNegative, labels, }: {
    view: StatementMatrixView;
    scale?: ReportScale;
    currency?: string;
    locale?: string;
    /** Set by a toolbar's expand/collapse-all action. */
    visibility?: StatementSectionVisibility;
    /** Increment when the same visibility command should run again. */
    visibilityRevision?: number;
    drillTarget?: (context: StatementMatrixDrillContext) => TDrillTarget | null | undefined;
    onDrill?: (target: TDrillTarget) => void;
    onOpenRow?: (line: StatementMatrixLine) => void;
    renderRowLink?: (line: StatementMatrixLine, content: React.ReactNode) => React.ReactNode;
    formatValue?: (context: StatementMatrixDrillContext & {
        scale: ReportScale;
        currency: string;
        locale?: string;
    }) => string;
    isNegative?: (value: number, column: StatementMatrixColumn) => boolean;
    labels?: {
        expandSection?: (section: string) => string;
        collapseSection?: (section: string) => string;
    };
}): React.JSX.Element;
//# sourceMappingURL=statement-matrix.d.ts.map