import { reportColumnExpression } from './entities.js';
import { resolvePreset } from './period-presets.js';
export const REPORT_FILTER_OPERATORS = [
    'eq', 'neq', 'in', 'not_in', 'gte', 'lte', 'contains',
    'is_null', 'is_not_null', 'is_true', 'is_false',
    'between_days_ago', 'due_within_days', 'since_today',
    'this_week', 'this_month', 'this_year', 'before_now',
    'period_preset',
];
const META_ROWS = [
    ['eq', 'is', 'one'], ['neq', 'is not', 'one'], ['in', 'is any of', 'list'], ['not_in', 'is none of', 'list'],
    ['gte', 'is at least', 'one'], ['lte', 'is at most', 'one'], ['contains', 'contains', 'one'],
    ['is_null', 'is empty', 'none'], ['is_not_null', 'is not empty', 'none'], ['is_true', 'is true', 'none'], ['is_false', 'is false', 'none'],
    ['between_days_ago', 'is within the last days', 'one'], ['due_within_days', 'is due within days', 'one'],
    ['since_today', 'is today', 'none'], ['this_week', 'is this week', 'none'], ['this_month', 'is this month', 'none'], ['this_year', 'is this year', 'none'], ['before_now', 'is before now', 'none'],
    ['period_preset', 'is in period', 'one'],
];
const OPERATOR_META = Object.fromEntries(META_ROWS.map(([key, label, needsValue]) => [key, { key, label, needsValue }]));
export function operatorsForKind(kind) {
    const keys = kind === 'boolean'
        ? ['is_true', 'is_false', 'is_null', 'is_not_null']
        : kind === 'date' || kind === 'timestamp'
            ? ['eq', 'gte', 'lte', 'period_preset', 'between_days_ago', 'due_within_days', 'since_today', 'this_week', 'this_month', 'this_year', 'before_now', 'is_null', 'is_not_null']
            : kind === 'number'
                ? ['eq', 'neq', 'gte', 'lte', 'in', 'not_in', 'is_null', 'is_not_null']
                : kind === 'enum'
                    ? ['eq', 'neq', 'in', 'not_in', 'is_null', 'is_not_null']
                    : ['eq', 'neq', 'contains', 'in', 'not_in', 'is_null', 'is_not_null'];
    return keys.map((key) => OPERATOR_META[key]);
}
export class SqlParameters {
    values = [];
    add(value) { this.values.push(value); return `$${this.values.length}`; }
}
export function compileReportRule(entity, rule, parameters, now = new Date(), fiscalStartMonth = 1) {
    const column = reportColumnExpression(entity, rule.field);
    if (!column)
        return null;
    const value = rule.value;
    const present = value !== null && value !== undefined && value !== '';
    switch (rule.op) {
        case 'eq': return present ? `${column} = ${parameters.add(value)}` : null;
        case 'neq': return present ? `${column} <> ${parameters.add(value)}` : null;
        case 'in':
        case 'not_in': {
            if (!Array.isArray(value) || !value.length)
                return null;
            const list = value.map((entry) => parameters.add(entry)).join(', ');
            return `${column} ${rule.op === 'not_in' ? 'NOT ' : ''}IN (${list})`;
        }
        case 'gte': return present ? `${column} >= ${parameters.add(value)}` : null;
        case 'lte': return present ? `${column} <= ${parameters.add(value)}` : null;
        case 'contains': return present ? `${column}::text ILIKE ${parameters.add(`%${String(value)}%`)}` : null;
        case 'is_null': return `${column} IS NULL`;
        case 'is_not_null': return `${column} IS NOT NULL`;
        case 'is_true': return `${column} IS TRUE`;
        case 'is_false': return `${column} IS FALSE`;
        case 'between_days_ago': {
            const days = Number(value ?? 30);
            return Number.isFinite(days) ? `${column} >= ${parameters.add(new Date(now.getTime() - days * 86_400_000).toISOString())}` : null;
        }
        case 'due_within_days': {
            const days = Number(value ?? 30);
            return Number.isFinite(days) ? `${column} <= ${parameters.add(new Date(now.getTime() + days * 86_400_000).toISOString())}` : null;
        }
        case 'since_today': return currentPeriod(column, 'day');
        case 'this_week': return currentPeriod(column, 'week');
        case 'this_month': return currentPeriod(column, 'month');
        case 'this_year': return currentPeriod(column, 'year');
        case 'before_now': return `${column} < now()`;
        case 'period_preset': {
            if (typeof value !== 'string')
                return null;
            const range = resolvePreset(value, { today: now.toISOString().slice(0, 10), startMonth: fiscalStartMonth });
            if (!range)
                return null;
            return `(${column} >= ${parameters.add(range.from)} AND ${column} <= ${parameters.add(range.to)})`;
        }
    }
}
export function compileReportRuleGroup(entity, group, parameters, options = {}) {
    let count = 0;
    const maxDepth = options.maxDepth ?? 5;
    const maxRules = options.maxRules ?? 60;
    const walk = (current, depth) => {
        if (depth > maxDepth)
            throw new Error('Filter tree is nested too deeply');
        const parts = [];
        for (const item of current.rules) {
            if (++count > maxRules)
                throw new Error('Filter tree contains too many rules');
            const compiled = isRuleGroup(item)
                ? walk(item, depth + 1)
                : compileReportRule(entity, item, parameters, options.now, options.fiscalStartMonth);
            if (compiled)
                parts.push(compiled);
        }
        if (!parts.length)
            return null;
        const joined = parts.length === 1 ? parts[0] : `(${parts.join(current.combinator === 'or' ? ' OR ' : ' AND ')})`;
        return current.not ? `NOT (${joined})` : joined;
    };
    return walk(group, 1);
}
function isRuleGroup(value) {
    return 'rules' in value;
}
function currentPeriod(column, unit) {
    return `(${column} >= date_trunc('${unit}', now()) AND ${column} < date_trunc('${unit}', now()) + interval '1 ${unit}')`;
}
//# sourceMappingURL=filters.js.map