import type { QueryResult } from '@appkit/analytics';
import type { ReportGroup, ReportRunResult, ReportSummaryItem } from './types.js';
export type ReportDocument = {
    title: string;
    subtitle?: string;
    generatedAt: Date;
    groups: ReportGroup[];
    summary: ReportSummaryItem[];
    rowCount: number;
};
export declare function queryResultToReport(result: QueryResult, options?: {
    title?: string;
    groupBy?: string;
    summary?: ReportSummaryItem[];
}): ReportRunResult;
export declare function createReportDocument(title: string, result: ReportRunResult, options?: {
    subtitle?: string;
    generatedAt?: Date;
}): ReportDocument;
export declare function displayCell(value: unknown): string;
//# sourceMappingURL=document.d.ts.map