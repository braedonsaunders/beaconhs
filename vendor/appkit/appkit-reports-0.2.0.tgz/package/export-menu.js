'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { ChevronDown, Download, FileText, Printer, Sheet } from 'lucide-react';
import { Button, Popover } from '@appkit/ui';
export async function printReportPdf(href) {
    const response = await fetch(href);
    if (!response.ok)
        throw new Error('The printable report could not be loaded.');
    const objectUrl = URL.createObjectURL(await response.blob());
    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    iframe.src = objectUrl;
    iframe.onload = () => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        window.setTimeout(() => { URL.revokeObjectURL(objectUrl); iframe.remove(); }, 60_000);
    };
    document.body.appendChild(iframe);
}
/** One compact report action containing print, PDF, spreadsheet, and CSV. */
export function ReportExportMenu({ options, printHref, label = 'Export', printLabel = 'Print', onError, }) {
    const [open, setOpen] = React.useState(false);
    const [busy, setBusy] = React.useState(false);
    const item = 'flex w-full items-center gap-2 rounded-md px-2.5 py-1.5 text-sm text-fg hover:bg-surface-hover';
    const icon = (format) => format === 'pdf' ? _jsx(FileText, { size: 14 }) : format === 'xlsx' ? _jsx(Sheet, { size: 14 }) : _jsx(Download, { size: 14 });
    const act = async (operation) => {
        setOpen(false);
        setBusy(true);
        try {
            await operation();
        }
        catch (cause) {
            onError?.(cause instanceof Error ? cause : new Error('The report action failed.'));
        }
        finally {
            setBusy(false);
        }
    };
    return _jsx(Popover, { open: open, onOpenChange: setOpen, align: "end", trigger: _jsxs(Button, { type: "button", variant: "outline", size: "sm", disabled: busy, onClick: () => setOpen((value) => !value), children: [_jsx(Download, { size: 14 }), label, _jsx(ChevronDown, { size: 13, className: "opacity-60" })] }), children: _jsxs("div", { className: "w-44 p-1", children: [printHref ? _jsxs("button", { type: "button", className: item, onClick: () => void act(() => printReportPdf(printHref)), children: [_jsx(Printer, { size: 14 }), printLabel] }) : null, options.map((option) => option.href ? _jsxs("a", { className: item, href: option.href, onClick: () => setOpen(false), children: [icon(option.format), option.label] }, option.format) : _jsxs("button", { type: "button", className: item, onClick: () => void act(option.onSelect ?? (() => undefined)), children: [icon(option.format), option.label] }, option.format))] }) });
}
//# sourceMappingURL=export-menu.js.map