import type { ReactNode } from 'react';
import { type ReportLayout } from './types.js';
/** The shared in-app paper surface used by report previews and result pages. */
export declare function ReportPaper({ organization, title, periodPhrase, note, wide, layout, children, className, }: {
    organization: string;
    title: string;
    periodPhrase?: string;
    note?: string;
    wide?: boolean;
    layout?: Partial<ReportLayout>;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;
//# sourceMappingURL=report-paper.d.ts.map