export const REPORT_PAPER_SIZES = ['letter', 'a4', 'legal'];
export const REPORT_DENSITIES = ['standard', 'compact'];
export const DEFAULT_REPORT_LAYOUT = {
    paperSize: 'letter',
    orientation: 'landscape',
    marginMm: 15,
    showSummary: true,
    density: 'standard',
};
export function resolveReportLayout(value) {
    const margin = Number(value?.marginMm);
    return {
        paperSize: REPORT_PAPER_SIZES.includes(value?.paperSize)
            ? value.paperSize
            : DEFAULT_REPORT_LAYOUT.paperSize,
        orientation: value?.orientation === 'portrait' ? 'portrait' : 'landscape',
        marginMm: Number.isFinite(margin) ? Math.min(30, Math.max(5, margin)) : 15,
        showSummary: value?.showSummary !== false,
        density: value?.density === 'compact' ? 'compact' : 'standard',
    };
}
export function assertReportDefinition(value) {
    if (value.schemaVersion !== 1)
        throw new Error('Unsupported report schema version');
    if (!value.id.trim() || !value.name.trim() || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value.slug)) {
        throw new Error('A report requires an id, name, and kebab-case slug');
    }
    if (!value.query.source.trim())
        throw new Error('A report requires a query source');
}
//# sourceMappingURL=types.js.map