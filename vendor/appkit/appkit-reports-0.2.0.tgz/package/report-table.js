import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from '@appkit/ui';
/** Report-only table primitives: ruled document typography without list chrome. */
export function ReportTable({ className, ...props }) {
    return _jsx("div", { className: "app-scroll w-full overflow-x-auto", children: _jsx("table", { className: cn('w-full border-collapse text-sm tabular-nums', className), ...props }) });
}
export function ReportTableHeader({ className, ...props }) {
    return _jsx("thead", { className: cn('[&_tr]:border-b [&_tr]:border-border-strong', className), ...props });
}
export function ReportTableBody({ className, ...props }) {
    return _jsx("tbody", { className: className, ...props });
}
export function ReportTableRow({ className, ...props }) {
    return _jsx("tr", { className: className, ...props });
}
export function ReportTableHead({ className, ...props }) {
    return _jsx("th", { className: cn('py-2 pr-4 text-left align-bottom text-xs font-semibold tracking-wide text-fg-muted uppercase last:pr-0', className), ...props });
}
export function ReportTableCell({ className, ...props }) {
    return _jsx("td", { className: cn('py-1 pr-4 align-top last:pr-0', className), ...props });
}
export const reportSubtotalRowClass = 'border-t border-border-strong';
export const reportTotalRowClass = 'border-t border-b-[3px] border-double border-border-strong';
//# sourceMappingURL=report-table.js.map