import type { ReportSchedule } from './types.js';
export type ParsedReportScheduleForm = Pick<ReportSchedule, 'definitionId' | 'name' | 'cadence' | 'repeatEvery' | 'dayOfWeek' | 'dayOfMonth' | 'weekOfMonth' | 'hour' | 'minute' | 'timezone' | 'startsOn' | 'endsOn' | 'recipientUserIds' | 'recipientEmails' | 'filters' | 'emailSubject' | 'emailMessage'>;
/**
 * Parses the exact shared create/edit field contract used by the production
 * schedule form. Create and update adapters should both call this function so
 * cadence, recipient, filter, timezone, date, and email validation cannot drift.
 */
export declare function parseReportScheduleForm(formData: FormData, options?: {
    defaultTimezone?: string;
}): ParsedReportScheduleForm;
//# sourceMappingURL=schedule-form.d.ts.map