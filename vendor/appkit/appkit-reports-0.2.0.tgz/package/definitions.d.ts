import type { ReportCustomQuery } from './custom-query.js';
import type { ReportLayout } from './types.js';
export type CustomReportDefinition = {
    schemaVersion: 1;
    id: string;
    slug: string;
    name: string;
    description?: string;
    query: ReportCustomQuery;
    layout: ReportLayout;
    state: 'draft' | 'published' | 'archived';
    tags?: string[];
    builtIn?: boolean;
};
export type ReportDefinitionRegistry = {
    definitions: CustomReportDefinition[];
    get(idOrSlug: string): CustomReportDefinition | null;
    list(options?: {
        state?: CustomReportDefinition['state'];
        tags?: string[];
    }): CustomReportDefinition[];
};
export declare function createReportDefinitionRegistry(definitions: CustomReportDefinition[]): ReportDefinitionRegistry;
export declare function assertCustomReportDefinition(value: CustomReportDefinition): void;
//# sourceMappingURL=definitions.d.ts.map