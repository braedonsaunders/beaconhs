import { queryResultToReport } from './document.js';
import { assertReportDefinition } from './types.js';
export async function runReport(definition, execute, options = {}) {
    assertReportDefinition(definition);
    if (definition.state === 'archived')
        throw new Error('Archived reports cannot be run');
    options.signal?.throwIfAborted();
    const result = await execute(definition.query, { signal: options.signal });
    options.signal?.throwIfAborted();
    return queryResultToReport(result, { title: definition.name, groupBy: options.groupBy });
}
//# sourceMappingURL=run.js.map