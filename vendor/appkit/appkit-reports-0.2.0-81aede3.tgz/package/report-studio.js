'use client';
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import * as React from 'react';
import { CalendarClock, CheckCircle2, ChevronDown, ChevronUp, Columns3, FileText, Filter, GripVertical, LayoutTemplate, Loader2, Play, Plus, Save, Search, Settings2, Sigma, Table2, Trash2, X } from 'lucide-react';
import { Button, Checkbox, Input, Label, SearchSelect, Textarea, cn } from '@appkit/ui';
import { REPORT_AGG_FNS, REPORT_TEMPORAL_BINS } from './custom-query.js';
import { defaultColumnsFor, reportColumn, reportEntity, visibleReportColumns } from './entities.js';
import { ReportFilterTree } from './filter-tree.js';
import { ReportDocumentView } from './document-view.js';
import { PaperView } from './paper-view.js';
import { ReportDrillDrawer } from './report-drill-drawer.js';
import { ReportExportMenu } from './export-menu.js';
import { reportRunResultToPaper } from './viewer-types.js';
export function ReportStudio({ value, catalog, result, onChange, onPreview, onSave, onSaved, organization = 'Organization', logoUrl, primaryColor, currency = '', drill, exports: exportOptions, printHref, pdfHref, templates, autoPreviewMs = 500, autoSaveMs = 700, className }) {
    const [preview, setPreview] = React.useState(result);
    const [running, setRunning] = React.useState(false);
    const [saving, setSaving] = React.useState(false);
    const [error, setError] = React.useState(null);
    const [tab, setTab] = React.useState('data');
    const [drillTarget, setDrillTarget] = React.useState(null);
    React.useEffect(() => setPreview(result), [result]);
    const definition = value.definition;
    const query = definition.query;
    const entity = reportEntity(catalog, query.entity) ?? catalog.entities[0] ?? null;
    const updateDefinition = (next) => onChange({ ...value, definition: { ...definition, ...next } });
    const updateQuery = (next) => updateDefinition({ query: next });
    async function run(next = value) {
        setRunning(true);
        setError(null);
        try {
            setPreview(await onPreview(next));
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : 'The report could not run.');
        }
        finally {
            setRunning(false);
        }
    }
    async function save(next = value) {
        setSaving(true);
        setError(null);
        try {
            const response = await onSave(next);
            if (!response.ok) {
                setError(response.error);
                return false;
            }
            const persisted = response.value ?? next;
            lastSavedKey.current = reportStudioPersistenceKey(persisted);
            if (response.value)
                onChange(response.value);
            onSaved?.(persisted, response);
            return true;
        }
        catch (cause) {
            setError(cause instanceof Error ? cause.message : 'The report could not be saved.');
            return false;
        }
        finally {
            setSaving(false);
        }
    }
    async function exportPdf() {
        if (!pdfHref)
            return;
        if (!(await save()))
            return;
        window.location.assign(pdfHref);
    }
    const previewKey = reportStudioPersistenceKey(value);
    const lastSavedKey = React.useRef(previewKey);
    React.useEffect(() => {
        if (autoPreviewMs === false)
            return;
        const timer = window.setTimeout(() => { void run(value); }, Math.max(0, autoPreviewMs));
        return () => window.clearTimeout(timer);
        // The serialized report input is the intentional dependency; callbacks are
        // application adapters and should not restart a settled preview.
    }, [previewKey, autoPreviewMs]);
    React.useEffect(() => {
        if (autoSaveMs === false)
            return;
        if (lastSavedKey.current === previewKey)
            return;
        const timer = window.setTimeout(() => { void save(value); }, Math.max(0, autoSaveMs));
        return () => window.clearTimeout(timer);
    }, [previewKey, autoSaveMs]);
    const studioTemplates = entity
        ? (typeof templates === 'function' ? templates(entity) : templates ?? reportStudioTemplates(entity))
        : [];
    const tabs = [
        { key: 'data', label: 'Data', icon: Table2 },
        { key: 'filter', label: 'Filter', icon: Filter },
        { key: 'format', label: 'Format', icon: Settings2 },
    ];
    return _jsxs("fieldset", { disabled: saving, "aria-busy": saving, className: cn('app-scroll grid h-full min-h-0 flex-1 overflow-y-auto lg:grid-cols-3 lg:overflow-hidden', className), children: [_jsxs("aside", { className: "flex min-h-0 flex-col border-b border-border bg-surface lg:col-span-1 lg:border-r lg:border-b-0", children: [_jsxs("div", { className: "shrink-0 space-y-3 border-b border-border p-4 lg:p-5", children: [_jsx(Field, { label: "Name", children: _jsx(Input, { value: definition.name, onChange: (event) => updateDefinition({ name: event.target.value, slug: slug(event.target.value) }) }) }), _jsx(Field, { label: "Description", children: _jsx(Textarea, { rows: 2, value: definition.description ?? '', onChange: (event) => updateDefinition({ description: event.target.value || undefined }) }) }), _jsx("div", { className: "grid grid-cols-3 gap-1 rounded-lg border border-border p-0.5", children: tabs.map((item) => _jsxs("button", { type: "button", onClick: () => setTab(item.key), className: cn('flex items-center justify-center gap-1.5 rounded-md px-2 py-1.5 text-sm font-medium transition-colors', tab === item.key ? 'bg-primary text-primary-fg' : 'text-fg-muted hover:bg-surface-hover hover:text-fg'), children: [_jsx(item.icon, { size: 14 }), item.label] }, item.key)) })] }), _jsxs("div", { className: "app-scroll min-h-0 flex-1 space-y-5 overflow-y-auto p-4 lg:p-5", children: [tab === 'data' ? _jsxs(_Fragment, { children: [_jsxs("section", { className: "grid gap-3", children: [_jsx(Field, { label: "Source", children: _jsx(SearchSelect, { value: query.entity, onChange: (entityKey) => { const next = reportEntity(catalog, entityKey); if (next)
                                                        updateQuery({ entity: next.key, mode: 'rows', columns: defaultColumnsFor(next), filters: null, groupBy: null, sort: next.defaultSort ?? null, sorts: next.defaultSort ? [next.defaultSort] : [], limit: query.limit ?? 1000 }); }, options: catalog.entities.map((item) => ({ value: item.key, label: item.label, hint: item.description, group: item.category })) }) }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(ModeButton, { active: (query.mode ?? 'rows') === 'rows', icon: _jsx(Columns3, {}), label: "Rows", onClick: () => updateQuery({ ...query, mode: 'rows' }) }), _jsx(ModeButton, { active: query.mode === 'summarize', icon: _jsx(Sigma, {}), label: "Summarize", onClick: () => updateQuery({ ...query, mode: 'summarize', measures: query.measures?.length ? query.measures : [{ fn: 'count' }] }) })] })] }), studioTemplates.length ? _jsx(BuilderSection, { title: "Templates", icon: _jsx(LayoutTemplate, {}), children: studioTemplates.map((template) => {
                                            const active = JSON.stringify(template.query) === JSON.stringify(query);
                                            return _jsxs("button", { type: "button", onClick: () => updateQuery(template.query), className: cn('flex w-full items-start gap-2 rounded-lg border px-2.5 py-2 text-left transition-colors', active ? 'border-primary bg-primary-subtle text-fg' : 'border-border bg-surface text-fg hover:border-primary/50 hover:bg-surface-hover'), children: [_jsx(CheckCircle2, { size: 14, className: cn('mt-0.5 shrink-0', active ? 'text-primary' : 'text-fg-subtle') }), _jsxs("span", { className: "min-w-0", children: [_jsx("span", { className: "block text-xs font-medium", children: template.label }), _jsx("span", { className: "mt-0.5 block text-[11px] leading-snug text-fg-muted", children: template.description })] })] }, template.id);
                                        }) }) : null, entity && (query.mode ?? 'rows') === 'rows' ? _jsx(RowsBuilder, { entity: entity, query: query, onChange: updateQuery }) : null, entity && query.mode === 'summarize' ? _jsx(SummaryBuilder, { entity: entity, query: query, onChange: updateQuery }) : null, entity ? _jsx(SortLimitBuilder, { entity: entity, query: query, onChange: updateQuery }) : null] }) : null, tab === 'filter' && entity ? _jsx(FiltersBuilder, { entity: entity, query: query, onChange: updateQuery }) : null, tab === 'format' ? _jsx(LayoutBuilder, { value: value, onChange: onChange }) : null] })] }), _jsxs("main", { className: "flex min-h-0 flex-col bg-bg-subtle lg:col-span-2", children: [_jsxs("header", { className: "flex min-h-14 shrink-0 flex-wrap items-center justify-between gap-3 border-b border-border bg-surface px-4", children: [_jsx("div", { className: "flex min-w-0 items-center gap-3", children: _jsxs("div", { className: "min-w-0", children: [_jsx("h2", { className: "truncate text-sm font-semibold text-fg", children: definition.name || 'Untitled report' }), _jsxs("p", { className: "truncate text-xs text-fg-muted", children: [entity?.label ?? 'Choose a source', " \u00B7 ", query.mode === 'summarize' ? 'Summary' : 'Detail rows'] })] }) }), _jsxs("div", { className: "flex items-center gap-2", children: [exportOptions?.length ? _jsx(ReportExportMenu, { options: exportOptions, printHref: printHref, onError: (cause) => setError(cause.message) }) : null, _jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: () => void run(), disabled: running, children: [running ? _jsx(Loader2, { className: "size-4 animate-spin" }) : _jsx(Play, { size: 14 }), "Run"] }), pdfHref ? _jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: () => void exportPdf(), disabled: saving, children: [_jsx(FileText, { size: 14 }), "PDF"] }) : null, _jsxs(Button, { type: "button", size: "sm", onClick: () => void save(), disabled: saving, children: [saving ? _jsx(Loader2, { className: "size-4 animate-spin" }) : _jsx(Save, { size: 14 }), "Save"] })] })] }), _jsxs("div", { className: "app-scroll min-h-0 flex-1 overflow-auto p-4 lg:p-6", children: [error ? _jsx("div", { role: "alert", className: "mb-4 rounded-lg border border-danger/30 bg-danger-subtle px-3 py-2 text-sm text-danger", children: error }) : null, preview ? _jsx("div", { className: "rounded-xl bg-bg p-3 sm:p-5", children: drill ? _jsx(PaperView, { organization: organization, data: reportRunResultToPaper(definition.name, preview, { periodPhrase: definition.description, layout: definition.layout, drillTarget: drill.target }), emptyLabel: "No rows match this report.", currency: currency, onDrill: setDrillTarget }) : _jsx(ReportDocumentView, { organization: organization, logoUrl: logoUrl, primaryColor: primaryColor, title: definition.name, description: definition.description, layout: definition.layout, result: preview }) }) : _jsx("div", { className: "grid min-h-96 place-items-center rounded-xl border border-dashed border-border bg-surface text-sm text-fg-subtle", children: "Run the report to preview it." })] })] }), drill ? _jsx(ReportDrillDrawer, { target: drillTarget, load: drill.load, onClose: () => setDrillTarget(null), onOpenRecord: drill.onOpenRecord }) : null] });
}
function RowsBuilder({ entity, query, onChange }) {
    const [columnSearch, setColumnSearch] = React.useState('');
    const selected = query.columns;
    const labels = query.columnLabels ?? {};
    const search = columnSearch.trim().toLowerCase();
    const columns = visibleReportColumns(entity);
    const available = columns.filter((column) => !selected.includes(column.key) && (!search || `${column.label} ${column.key}`.toLowerCase().includes(search)));
    const setColumns = (columns) => onChange({ ...query, columns, columnLabels: Object.fromEntries(Object.entries(labels).filter(([key]) => columns.includes(key))) });
    const move = (index, delta) => { const target = index + delta; if (target < 0 || target >= selected.length)
        return; const columns = [...selected]; [columns[index], columns[target]] = [columns[target], columns[index]]; setColumns(columns); };
    const setLabel = (key, value) => { const next = { ...labels }; if (value.trim())
        next[key] = value;
    else
        delete next[key]; onChange({ ...query, columnLabels: next }); };
    return _jsxs(BuilderSection, { title: "Columns", icon: _jsx(Columns3, {}), children: [_jsxs("div", { className: "relative", children: [_jsx(Search, { size: 13, className: "pointer-events-none absolute top-1/2 left-2.5 -translate-y-1/2 text-fg-subtle" }), _jsx(Input, { value: columnSearch, onChange: (event) => setColumnSearch(event.target.value), placeholder: "Search columns", className: "h-8 pl-7 text-xs" })] }), _jsxs("div", { className: "flex flex-wrap gap-1.5", children: [_jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setColumns(defaultColumnsFor(entity)), children: "Defaults" }), _jsx(Button, { type: "button", variant: "outline", size: "sm", onClick: () => setColumns(columns.map((column) => column.key)), children: "All" }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => setColumns([]), children: "Clear" })] }), selected.length === 0 ? _jsx("p", { className: "text-xs text-danger", children: "Select at least one column." }) : _jsx("ul", { className: "space-y-1", children: selected.map((key, index) => { const column = reportColumn(entity, key); return _jsxs("li", { className: "flex items-center gap-1.5", children: [_jsx("span", { className: "min-w-0 flex-1 truncate rounded-md border border-border bg-bg-subtle px-2 py-1 text-xs text-fg", children: column?.label ?? key }), _jsx(Input, { className: "h-7 w-32 text-xs", value: labels[key] ?? '', onChange: (event) => setLabel(key, event.target.value), placeholder: "Label override" }), _jsx("button", { type: "button", onClick: () => move(index, -1), disabled: index === 0, "aria-label": "Move column up", className: "rounded p-1 text-fg-subtle hover:bg-surface-hover hover:text-fg disabled:opacity-30", children: _jsx(ChevronUp, { size: 14 }) }), _jsx("button", { type: "button", onClick: () => move(index, 1), disabled: index === selected.length - 1, "aria-label": "Move column down", className: "rounded p-1 text-fg-subtle hover:bg-surface-hover hover:text-fg disabled:opacity-30", children: _jsx(ChevronDown, { size: 14 }) }), _jsx("button", { type: "button", onClick: () => setColumns(selected.filter((columnKey) => columnKey !== key)), "aria-label": "Remove column", className: "rounded p-1 text-fg-subtle hover:bg-danger-subtle hover:text-danger", children: _jsx(X, { size: 14 }) })] }, key); }) }), available.length ? _jsx("div", { className: "flex max-h-48 flex-wrap gap-1.5 overflow-y-auto pt-1", children: available.map((column) => _jsx("button", { type: "button", onClick: () => setColumns([...selected, column.key]), className: "rounded-full border border-border px-2.5 py-1 text-xs text-fg-muted transition-colors hover:border-primary hover:text-primary", children: _jsxs("span", { className: "inline-flex items-center gap-1", children: [_jsx(Plus, { size: 11 }), column.label] }) }, column.key)) }) : search ? _jsx("p", { className: "text-xs text-fg-subtle", children: "No columns match." }) : null, _jsx(Field, { label: "Group rows into sections", children: _jsx(SearchSelect, { value: query.groupBy ?? '', onChange: (groupBy) => onChange({ ...query, groupBy: groupBy || null }), options: [{ value: '', label: 'No grouping' }, ...columns.map((column) => ({ value: column.key, label: column.label }))] }) })] });
}
function SummaryBuilder({ entity, query, onChange }) {
    const breakouts = query.breakouts ?? [], measures = query.measures ?? [];
    const columns = visibleReportColumns(entity);
    return _jsxs(_Fragment, { children: [_jsx(BuilderSection, { title: "Group by", icon: _jsx(GripVertical, {}), action: () => onChange({ ...query, breakouts: [...breakouts, { column: columns[0]?.key ?? '' }] }), children: breakouts.map((breakout, index) => { const column = reportColumn(entity, breakout.column); const temporal = column?.kind === 'date' || column?.kind === 'timestamp'; return _jsxs("div", { className: "flex gap-2", children: [_jsx(SearchSelect, { className: "min-w-0 flex-1", value: breakout.column, onChange: (columnKey) => onChange({ ...query, breakouts: breakouts.map((item, itemIndex) => itemIndex === index ? { ...item, column: columnKey, bin: undefined } : item) }), options: columns.map((item) => ({ value: item.key, label: item.label })) }), temporal ? _jsx(SearchSelect, { className: "w-32", value: breakout.bin ?? '', onChange: (bin) => onChange({ ...query, breakouts: breakouts.map((item, itemIndex) => itemIndex === index ? { ...item, bin: bin ? bin : undefined } : item) }), options: [{ value: '', label: 'Exact' }, ...REPORT_TEMPORAL_BINS.map((bin) => ({ value: bin, label: bin.replace('_', ' ') }))] }) : null, _jsx(RemoveButton, { onClick: () => onChange({ ...query, breakouts: breakouts.filter((_, itemIndex) => itemIndex !== index) }) })] }, index); }) }), _jsx(BuilderSection, { title: "Measures", icon: _jsx(Sigma, {}), action: () => onChange({ ...query, measures: [...measures, { fn: 'count' }] }), children: measures.map((measure, index) => _jsxs("div", { className: "flex gap-2", children: [_jsx(SearchSelect, { className: "w-32", value: measure.fn, onChange: (fn) => onChange({ ...query, measures: measures.map((item, itemIndex) => itemIndex === index ? { ...item, fn: fn, column: fn === 'count' ? undefined : item.column ?? columns.find((column) => column.kind === 'number')?.key } : item) }), options: REPORT_AGG_FNS.map((fn) => ({ value: fn, label: fn.replace('_', ' ') })) }), measure.fn !== 'count' ? _jsx(SearchSelect, { className: "min-w-0 flex-1", value: measure.column ?? '', onChange: (column) => onChange({ ...query, measures: measures.map((item, itemIndex) => itemIndex === index ? { ...item, column } : item) }), options: columns.filter((column) => !['sum', 'avg'].includes(measure.fn) || column.kind === 'number').map((column) => ({ value: column.key, label: column.label })) }) : _jsx("div", { className: "flex flex-1 items-center rounded-md border border-border bg-bg-subtle px-3 text-sm text-fg-muted", children: "Rows" }), _jsx(RemoveButton, { onClick: () => onChange({ ...query, measures: measures.filter((_, itemIndex) => itemIndex !== index) }) })] }, index)) })] });
}
function FiltersBuilder({ entity, query, onChange }) {
    const filters = query.filters ?? { combinator: 'and', rules: [] };
    return _jsx(BuilderSection, { title: "Filters", icon: _jsx(Filter, {}), children: _jsx(ReportFilterTree, { entity: entity, group: filters, onChange: (next) => onChange({ ...query, filters: next.rules.length ? next : null }) }) });
}
function SortLimitBuilder({ entity, query, onChange }) {
    const columns = visibleReportColumns(entity);
    const sorts = query.sorts?.length ? query.sorts : query.sort ? [query.sort] : [];
    const commit = (next) => {
        const cleaned = next.filter((sort) => sort.column).slice(0, 3);
        onChange({ ...query, sorts: cleaned.length ? cleaned : null, sort: cleaned[0] ?? null });
    };
    const used = new Set(sorts.map((sort) => sort.column));
    return _jsxs(BuilderSection, { title: "Rows", icon: _jsx(Table2, {}), children: [_jsxs("div", { className: "space-y-2", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx(Label, { children: "Sort by" }), sorts.length > 0 && sorts.length < 3 ? _jsxs(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => { const first = columns.find((column) => !used.has(column.key)); if (first)
                                    commit([...sorts, { column: first.key, direction: 'desc' }]); }, children: [_jsx(Plus, { size: 14 }), "Add level"] }) : null] }), sorts.length === 0 ? _jsx(SearchSelect, { value: "", onChange: (column) => column && commit([{ column, direction: 'desc' }]), options: [{ value: '', label: 'Default order' }, ...columns.map((column) => ({ value: column.key, label: column.label }))] }) : sorts.map((sort, index) => _jsxs("div", { className: "flex items-center gap-2", children: [index > 0 ? _jsx("span", { className: "w-12 shrink-0 text-right text-[11px] text-fg-subtle", children: "then by" }) : null, _jsx(SearchSelect, { className: "min-w-0 flex-1", value: sort.column, onChange: (column) => commit(sorts.map((item, itemIndex) => itemIndex === index ? { ...item, column } : item)), options: columns.filter((column) => !used.has(column.key) || column.key === sort.column).map((column) => ({ value: column.key, label: column.label })) }), _jsx(SearchSelect, { className: "w-32", value: sort.direction, onChange: (direction) => commit(sorts.map((item, itemIndex) => itemIndex === index ? { ...item, direction: direction } : item)), options: [{ value: 'desc', label: 'Descending' }, { value: 'asc', label: 'Ascending' }] }), _jsx(RemoveButton, { onClick: () => commit(sorts.filter((_, itemIndex) => itemIndex !== index)) })] }, index))] }), _jsx(Field, { label: "Row limit", children: _jsx(Input, { type: "number", min: 1, max: 10_000, value: query.limit ?? 1000, onChange: (event) => onChange({ ...query, limit: Math.min(10_000, Math.max(1, Number(event.currentTarget.value) || 1)) }) }) }), _jsx("p", { className: "text-xs text-fg-muted", children: "The preview and exports enforce the same bounded query plan." })] });
}
function LayoutBuilder({ value, onChange }) {
    const layout = value.definition.layout, schedule = value.schedule;
    const changeLayout = (next) => onChange({ ...value, definition: { ...value.definition, layout: { ...layout, ...next } } });
    return _jsxs(BuilderSection, { title: "Page and delivery", icon: _jsx(CalendarClock, {}), children: [_jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsx(Field, { label: "Paper", children: _jsx(SearchSelect, { value: layout.paperSize, onChange: (paperSize) => changeLayout({ paperSize: paperSize }), options: ['letter', 'a4', 'legal'].map((item) => ({ value: item, label: item.toUpperCase() })) }) }), _jsx(Field, { label: "Orientation", children: _jsx(SearchSelect, { value: layout.orientation, onChange: (orientation) => changeLayout({ orientation: orientation }), options: [{ value: 'portrait', label: 'Portrait' }, { value: 'landscape', label: 'Landscape' }] }) }), _jsx(Field, { label: "Density", children: _jsx(SearchSelect, { value: layout.density, onChange: (density) => changeLayout({ density: density }), options: [{ value: 'standard', label: 'Standard' }, { value: 'compact', label: 'Compact' }] }) }), _jsx(Field, { label: "Margin (mm)", children: _jsx(Input, { type: "number", min: 5, max: 30, value: layout.marginMm, onChange: (event) => changeLayout({ marginMm: Math.min(30, Math.max(5, Number(event.currentTarget.value) || 15)) }) }) })] }), _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: layout.showSummary, onChange: (event) => changeLayout({ showSummary: event.currentTarget.checked }) }), "Show summary band"] }), schedule ? _jsxs("label", { className: "flex items-center gap-2 text-sm text-fg", children: [_jsx(Checkbox, { checked: schedule.active, onChange: (event) => onChange({ ...value, schedule: { ...schedule, active: event.target.checked } }) }), "Scheduled delivery enabled"] }) : null] });
}
/** Generic production templates derived only from the injected catalogue. */
export function reportStudioTemplates(entity) {
    const columns = defaultColumnsFor(entity);
    const visibleColumns = visibleReportColumns(entity);
    const base = {
        entity: entity.key,
        mode: 'rows',
        columns,
        breakouts: [],
        measures: [],
        filters: null,
        groupBy: null,
        sort: entity.defaultSort ?? null,
        sorts: entity.defaultSort ? [entity.defaultSort] : null,
        limit: 1000,
    };
    const temporal = visibleColumns.find((column) => column.key === 'month') ?? visibleColumns.find((column) => column.key.endsWith('_on')) ?? visibleColumns.find((column) => column.key.endsWith('_at')) ?? visibleColumns.find((column) => column.kind === 'date' || column.kind === 'timestamp');
    const category = visibleColumns.find((column) => column.key === 'status') ?? visibleColumns.find((column) => column.kind === 'enum') ?? visibleColumns.find((column) => column.kind === 'text' && !column.key.endsWith('_id'));
    const numeric = visibleColumns.find((column) => column.kind === 'number');
    const templates = [{ id: 'detail-register', label: 'Detail register', description: 'Selected columns in source order with the default sort.', query: base }];
    if (category)
        templates.push({ id: 'grouped-register', label: `Grouped by ${category.label}`, description: 'Detail rows organized into report sections.', query: { ...base, groupBy: category.key } });
    if (temporal)
        templates.push({
            id: 'monthly-activity',
            label: numeric ? `Monthly ${numeric.label}` : 'Monthly activity',
            description: numeric ? `Monthly total and record count for ${numeric.label.toLowerCase()}.` : 'Monthly record count.',
            query: { entity: entity.key, mode: 'summarize', columns: [], breakouts: [{ column: temporal.key, bin: 'month' }], measures: numeric ? [{ fn: 'sum', column: numeric.key }, { fn: 'count' }] : [{ fn: 'count' }], filters: null, groupBy: null, sort: null, sorts: null, limit: 1000 },
        });
    if (category && numeric)
        templates.push({
            id: 'totals-by-category',
            label: `${numeric.label} by ${category.label}`,
            description: `Rank ${category.label.toLowerCase()} values by ${numeric.label.toLowerCase()}.`,
            query: { entity: entity.key, mode: 'summarize', columns: [], breakouts: [{ column: category.key }], measures: [{ fn: 'sum', column: numeric.key }, { fn: 'count' }], filters: null, groupBy: null, sort: null, sorts: null, limit: 1000 },
        });
    return templates;
}
export function ReportResultView({ organization = 'Organization', logoUrl, primaryColor, title = 'Report', description, layout, result }) {
    return _jsx(ReportDocumentView, { organization: organization, logoUrl: logoUrl, primaryColor: primaryColor, title: title, description: description, layout: layout, result: result });
}
function BuilderSection({ title, icon, action, children }) { return _jsxs("section", { className: "space-y-3 rounded-xl border border-border bg-surface p-3", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsxs("h3", { className: "flex items-center gap-2 text-sm font-semibold text-fg", children: [_jsx("span", { className: "text-primary [&_svg]:size-4", children: icon }), title] }), action ? _jsxs(Button, { type: "button", variant: "ghost", size: "sm", onClick: action, children: [_jsx(Plus, { size: 13 }), "Add"] }) : null] }), children] }); }
function Field({ label, children }) { return _jsxs("div", { className: "space-y-1.5", children: [_jsx(Label, { children: label }), children] }); }
function ModeButton({ active, icon, label, onClick }) { return _jsxs("button", { type: "button", onClick: onClick, className: cn('flex items-center justify-center gap-2 rounded-lg border px-3 py-2 text-sm transition [&_svg]:size-4', active ? 'border-primary bg-primary-subtle text-primary' : 'border-border bg-surface text-fg-muted hover:bg-surface-hover'), children: [icon, label] }); }
function RemoveButton({ onClick }) { return _jsx("button", { type: "button", "aria-label": "Remove", onClick: onClick, className: "grid size-9 shrink-0 place-items-center rounded-md text-fg-subtle hover:bg-danger-subtle hover:text-danger", children: _jsx(Trash2, { size: 14 }) }); }
function slug(value) { return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'untitled-report'; }
function reportStudioPersistenceKey(value) {
    return JSON.stringify({
        definition: value.definition,
        schedule: value.schedule ?? null,
    });
}
//# sourceMappingURL=report-studio.js.map