import type { ReportLayout, ReportRunResult } from './types.js';
/**
 * Screen representation of the canonical report document. PDF printers consume
 * the same body builder and CSS, leaving only the outer paper frame screen-only.
 */
export declare function ReportDocumentView({ organization, logoUrl, primaryColor, title, description, layout, result, className, }: {
    organization: string;
    logoUrl?: string | null;
    primaryColor?: string | null;
    title: string;
    description?: string;
    layout?: Partial<ReportLayout>;
    result: ReportRunResult;
    className?: string;
}): import("react").JSX.Element;
//# sourceMappingURL=document-view.d.ts.map