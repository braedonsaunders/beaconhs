export type ReportColumnKind = 'text' | 'number' | 'date' | 'timestamp' | 'boolean' | 'enum' | 'uuid';
export type ReportEntityColumn = {
    key: string;
    label: string;
    kind: ReportColumnKind;
    /** Application-authored SQL expression. */
    expression?: string;
    /** Source-compatible expression key used by the production catalogues. */
    expr?: string;
    /** Physical column override for schema-discovered catalogues. */
    sql?: string;
    /** Synthetic JSON/array columns are omitted from printable documents. */
    arrayUnnest?: 'array' | 'jsonb';
    description?: string;
    /**
     * Tenant-resolved values that can legally be used to filter this column.
     * Hosts populate this for enums and reference-backed dimensions alike.
     */
    filterOptions?: readonly {
        value: string;
        label: string;
    }[];
    /**
     * Flat reporting views may expose a many-valued dimension as a comma-delimited
     * set. In that case equality and set operators target membership, not the
     * serialized string as a whole.
     */
    filterValueMode?: 'scalar' | 'csv-set';
    /** Source-compatible raw enum values. */
    options?: readonly string[];
};
export type ReportEntity = {
    key: string;
    label: string;
    category: string;
    description?: string;
    /** Application-authored FROM clause, or a physical RLS-scoped table. */
    from?: string;
    table?: string;
    tenantColumn?: string;
    /** Source-compatible organization scope expression. */
    orgColumn?: string;
    columns: ReportEntityColumn[];
    defaultColumns?: string[];
    defaultSort?: {
        column: string;
        direction: 'asc' | 'desc';
    };
    softDelete?: boolean;
    /** Explicit authored predicate when `from` is not a plain table. */
    softDeleteExpression?: string;
    /** Implicit permission/scope filter applied to every custom query. */
    baseFilter?: import('./filters').ReportRuleGroup;
    relations?: {
        via: string;
        target: string;
        foreignColumn: string;
        label: string;
    }[];
};
export type ReportEntityCatalog = {
    entities: ReportEntity[];
};
export declare function reportEntity(catalog: ReportEntityCatalog, key: string): ReportEntity | null;
export declare function reportColumn(entity: ReportEntity, key: string): ReportEntityColumn | null;
export declare function reportColumnExpression(entity: ReportEntity, key: string): string | null;
export declare function reportEntityFrom(entity: ReportEntity): string;
export declare function reportTenantColumn(entity: ReportEntity): string;
export declare function defaultColumnsFor(entity: ReportEntity, limit?: number): string[];
export declare function reportColumnOptions(column: ReportEntityColumn): {
    value: string;
    label: string;
}[];
//# sourceMappingURL=entities.d.ts.map