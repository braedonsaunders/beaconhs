'use client';
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Plus, Trash2, X } from 'lucide-react';
import { Button, Input, SearchSelect, Select } from '@appkit/ui';
import { operatorsForKind } from './filters.js';
import { PERIOD_PRESETS, PERIOD_PRESET_GROUP_LABELS } from './period-presets.js';
import { reportColumnOptions } from './entities.js';
const GROUP_ORDER = ['fiscal_year', 'fiscal_quarter', 'fiscal_half', 'period', 'calendar', 'rolling', 'days'];
function isGroup(node) { return 'rules' in node; }
export function defaultOperatorForColumn(column) {
    if (reportColumnOptions(column).length)
        return 'in';
    return operatorsForKind(column.kind)[0]?.key ?? 'eq';
}
/** Recursive nested and/or filter editor matching the tree consumed by the SQL compiler. */
export function ReportFilterTree({ entity, group, onChange, depth = 0 }) {
    const setRule = (index, rule) => { const rules = [...group.rules]; rules[index] = rule; onChange({ ...group, rules }); };
    const remove = (index) => onChange({ ...group, rules: group.rules.filter((_, current) => current !== index) });
    const addRule = () => {
        const column = entity.columns[0];
        if (column) {
            const op = defaultOperatorForColumn(column);
            onChange({ ...group, rules: [...group.rules, { field: column.key, op, value: op === 'in' ? [] : '' }] });
        }
    };
    return _jsxs("div", { className: depth === 0 ? 'space-y-2 rounded-lg border border-border p-3' : 'space-y-2 rounded-lg border border-border bg-bg-subtle p-3', children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("span", { className: "text-xs text-fg-muted", children: "Match" }), _jsxs(Select, { className: "h-8 w-48", value: group.combinator, onChange: (event) => onChange({ ...group, combinator: event.target.value }), children: [_jsx("option", { value: "and", children: "all conditions" }), _jsx("option", { value: "or", children: "any condition" })] })] }), _jsxs("div", { className: "space-y-2", children: [group.rules.map((rule, index) => isGroup(rule) ? _jsx(ReportFilterTree, { entity: entity, group: rule, depth: depth + 1, onChange: (next) => setRule(index, next) }, index) : _jsx(RuleRow, { entity: entity, rule: rule, onChange: (next) => setRule(index, next), onRemove: () => remove(index) }, index)), group.rules.length === 0 ? _jsx("p", { className: "text-xs text-fg-subtle", children: "No conditions." }) : null] }), _jsxs("div", { className: "flex gap-2", children: [_jsxs(Button, { type: "button", variant: "outline", size: "sm", onClick: addRule, children: [_jsx(Plus, { size: 14 }), "Add condition"] }), depth < 3 ? _jsxs(Button, { type: "button", variant: "ghost", size: "sm", onClick: () => onChange({ ...group, rules: [...group.rules, { combinator: 'and', rules: [] }] }), children: [_jsx(Plus, { size: 14 }), "Add group"] }) : null] })] });
}
function RuleRow({ entity, rule, onChange, onRemove }) {
    const column = entity.columns.find((item) => item.key === rule.field) ?? entity.columns[0];
    const operators = column ? operatorsForKind(column.kind) : [];
    const operator = operators.find((item) => item.key === rule.op) ?? operators[0];
    const options = column ? reportColumnOptions(column) : [];
    const changeField = (field) => {
        const nextColumn = entity.columns.find((item) => item.key === field);
        if (!nextColumn)
            return;
        const nextOperator = defaultOperatorForColumn(nextColumn);
        onChange({ field, op: nextOperator, value: nextOperator === 'in' ? [] : '' });
    };
    return _jsxs("div", { className: "flex flex-wrap items-center gap-2", children: [_jsx(Select, { className: "h-8 min-w-40", value: rule.field, onChange: (event) => changeField(event.target.value), children: entity.columns.map((item) => _jsx("option", { value: item.key, children: item.label }, item.key)) }), _jsx(Select, { className: "h-8 min-w-36", value: rule.op, onChange: (event) => {
                    const op = event.target.value;
                    const needsList = operators.find((item) => item.key === op)?.needsValue === 'list';
                    onChange({ ...rule, op, value: needsList ? (Array.isArray(rule.value) ? rule.value : []) : (Array.isArray(rule.value) ? '' : rule.value) });
                }, children: operators.map((item) => _jsx("option", { value: item.key, children: item.label }, item.key)) }), rule.op === 'period_preset' ? _jsx(Select, { className: "h-8 w-52", value: typeof rule.value === 'string' ? rule.value : 'this_fiscal_year', onChange: (event) => onChange({ ...rule, value: event.target.value }), children: GROUP_ORDER.map((group) => _jsx("optgroup", { label: PERIOD_PRESET_GROUP_LABELS[group], children: PERIOD_PRESETS.filter((preset) => preset.group === group).map((preset) => _jsx("option", { value: preset.id, children: preset.label }, preset.id)) }, group)) })
                : operator?.needsValue === 'one' && options.length ? _jsx(SearchSelect, { className: "w-52", triggerClassName: "h-8", value: typeof rule.value === 'string' ? rule.value : '', onChange: (value) => onChange({ ...rule, value }), options: options, clearable: true, placeholder: "Choose a value", ariaLabel: "Filter value" })
                    : operator?.needsValue === 'one' ? _jsx(Input, { className: "h-8 w-40", type: column?.kind === 'date' ? 'date' : column?.kind === 'number' ? 'number' : 'text', value: typeof rule.value === 'string' || typeof rule.value === 'number' ? String(rule.value) : '', placeholder: "Value", onChange: (event) => onChange({ ...rule, value: event.target.value }) })
                        : operator?.needsValue === 'list' && options.length ? _jsx(MultiSelect, { value: Array.isArray(rule.value) ? rule.value.map(String) : [], options: options, onChange: (next) => onChange({ ...rule, value: next }) })
                            : operator?.needsValue === 'list' ? _jsx(TokenInput, { value: Array.isArray(rule.value) ? rule.value.map(String) : [], onChange: (next) => onChange({ ...rule, value: next }) })
                                : _jsx("span", { className: "text-xs text-fg-subtle", children: "No value" }), _jsx(Button, { type: "button", variant: "ghost", size: "sm", onClick: onRemove, "aria-label": "Remove condition", children: _jsx(Trash2, { size: 14 }) })] });
}
function Chip({ label, onRemove, tone = 'primary' }) {
    return _jsxs("button", { type: "button", onClick: onRemove, className: tone === 'primary'
            ? 'inline-flex items-center gap-1 rounded-full border border-primary bg-primary-subtle px-2 py-0.5 text-xs text-primary'
            : 'inline-flex items-center gap-1 rounded-full border border-border px-2 py-0.5 text-xs text-fg-muted hover:border-border-strong', children: [_jsx("span", { className: "max-w-52 truncate", children: label }), _jsx(X, { size: 12, className: "shrink-0" })] });
}
/** Searchable add-a-value control plus removable chips for the selected set. */
function MultiSelect({ value, options, onChange }) {
    const selected = new Set(value);
    const remaining = options.filter((option) => !selected.has(option.value));
    const labelOf = (candidate) => options.find((option) => option.value === candidate)?.label ?? candidate;
    return _jsxs("div", { className: "flex max-w-md flex-col gap-1.5", children: [_jsx(SearchSelect, { className: "w-52", triggerClassName: "h-8", value: "", onChange: (next) => { if (next)
                    onChange([...value, next]); }, options: remaining, placeholder: "Add value\u2026", ariaLabel: "Add filter value" }), value.length ? _jsx("div", { className: "flex flex-wrap gap-1", children: value.map((item) => _jsx(Chip, { label: labelOf(item), onRemove: () => onChange(value.filter((current) => current !== item)) }, item)) }) : null] });
}
/** Free-text multi-value entry: type a value, press Enter to add it as a chip. */
function TokenInput({ value, onChange }) {
    const [draft, setDraft] = useState('');
    const commit = () => { const trimmed = draft.trim(); if (trimmed && !value.includes(trimmed))
        onChange([...value, trimmed]); setDraft(''); };
    return _jsxs("div", { className: "flex max-w-md flex-col gap-1.5", children: [_jsx(Input, { className: "h-8 w-52", value: draft, placeholder: "Type a value, press Enter", onChange: (event) => setDraft(event.target.value), onBlur: commit, onKeyDown: (event) => {
                    if (event.key === 'Enter') {
                        event.preventDefault();
                        commit();
                    }
                    else if (event.key === 'Backspace' && !draft && value.length)
                        onChange(value.slice(0, -1));
                } }), value.length ? _jsx("div", { className: "flex flex-wrap gap-1", children: value.map((item) => _jsx(Chip, { label: item, tone: "neutral", onRemove: () => onChange(value.filter((current) => current !== item)) }, item)) }) : null] });
}
//# sourceMappingURL=filter-tree.js.map