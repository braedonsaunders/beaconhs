import * as React from 'react';
import { type ListSearchParams } from './list-params.js';
export type PaginationLabels = {
    showing: (from: string, to: string, total: string) => React.ReactNode;
    noResults: string;
    prev: string;
    next: string;
    pageOf: (page: number, pages: number) => string;
    outOfRange: (page: string) => string;
    goToPage: (page: string) => string;
};
/**
 * URL-driven pagination row: showing X–Y of N + prev/next. When the current
 * page is past the end (a filter shrank the list), offers a jump to the last
 * page. Localized copy is supplied through the labels prop.
 */
export declare function Pagination({ basePath, currentParams, total, page, perPage, pageParamKey, labels: labelOverrides, }: {
    basePath: string;
    currentParams: ListSearchParams;
    total: number;
    page: number;
    perPage: number;
    /** URL param that carries the page number. Sub-tables pass a prefixed key. */
    pageParamKey?: string;
    labels?: Partial<PaginationLabels>;
}): React.JSX.Element;
//# sourceMappingURL=list-pagination.d.ts.map