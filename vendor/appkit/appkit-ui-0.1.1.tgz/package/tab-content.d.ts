import * as React from 'react';
/**
 * Wraps tab-panel content so swapping between tabs crossfades the outgoing
 * panel out and the incoming panel in. The `tabKey` prop is the
 * discriminator — when it changes, AnimatePresence runs the exit/enter
 * choreography.
 *
 * Usage (inside a detail page that already renders the active tab body
 * based on URL state):
 *
 *   <TabContent tabKey={active}>
 *     {active === 'overview' ? <OverviewPanel/> : null}
 *     {active === 'history'  ? <HistoryPanel/>  : null}
 *   </TabContent>
 *
 * Reduced-motion users get an instant swap.
 */
export declare function TabContent({ tabKey, children, className, duration, }: {
    tabKey: string;
    children: React.ReactNode;
    className?: string;
    duration?: number;
}): React.JSX.Element;
//# sourceMappingURL=tab-content.d.ts.map