import * as React from 'react';
export type SkeletonProps = React.HTMLAttributes<HTMLDivElement>;
/**
 * Skeleton placeholder with a left→right shimmer sweep (`.appkit-shimmer` in
 * tokens.css — pure CSS, so it works server-rendered). Reduced-motion users get
 * a static placeholder.
 */
export declare function Skeleton({ className, ...props }: SkeletonProps): React.JSX.Element;
//# sourceMappingURL=skeleton.d.ts.map