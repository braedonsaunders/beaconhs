import * as React from 'react';
export interface SubtabItem {
    key: string;
    label: React.ReactNode;
    count?: number;
    disabled?: boolean;
}
export interface SubtabNavProps {
    tabs: SubtabItem[];
    active: string;
    onSelect?: (key: string) => void;
    ariaLabel?: string;
    className?: string;
}
/** Source detail/drawer subtab bar, tokenized and reusable across page shells. */
export declare function SubtabNav({ tabs, active, onSelect, ariaLabel, className, }: SubtabNavProps): React.JSX.Element;
//# sourceMappingURL=subtab-nav.d.ts.map