import * as React from 'react';
export type AvatarProps = {
    src?: string;
    name?: string;
    size?: number;
    className?: string;
};
export declare function Avatar({ src, name, size, className }: AvatarProps): React.JSX.Element;
//# sourceMappingURL=avatar.d.ts.map