'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
const ListNavContext = React.createContext(null);
export function ListNavProvider({ value, children }) {
    return _jsx(ListNavContext.Provider, { value: value, children: children });
}
/** The wired router, or a window-backed fallback (null during SSR). */
export function useListNav() {
    const wired = React.useContext(ListNavContext);
    const [fallback, setFallback] = React.useState(null);
    React.useEffect(() => {
        if (wired)
            return;
        const make = () => ({
            pathname: window.location.pathname,
            search: window.location.search.replace(/^\?/, ''),
            replace: (href) => window.location.replace(href),
            push: (href) => window.location.assign(href),
        });
        setFallback(make());
        const onPop = () => setFallback(make());
        window.addEventListener('popstate', onPop);
        return () => window.removeEventListener('popstate', onPop);
    }, [wired]);
    return wired ?? fallback;
}
/** Anchor click handler: soft-navigate through the wired router when the click
 *  is a plain left-click (no modifiers), else let the browser handle it. */
export function useListNavClick(href) {
    const nav = React.useContext(ListNavContext);
    return React.useCallback((e) => {
        if (!nav)
            return;
        if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey)
            return;
        e.preventDefault();
        nav.push(href);
    }, [nav, href]);
}
//# sourceMappingURL=list-nav.js.map