'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext } from 'react';
const UiTextContext = createContext((value) => value);
/** Injects the host application's exact-copy translator into framework-agnostic UI primitives. */
export function UiTextProvider({ translate, children, }) {
    return _jsx(UiTextContext.Provider, { value: translate, children: children });
}
export function useUiText() {
    return useContext(UiTextContext);
}
//# sourceMappingURL=text-context.js.map