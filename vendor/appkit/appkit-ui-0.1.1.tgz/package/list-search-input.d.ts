import * as React from 'react';
/**
 * URL-driven search box: debounced 250ms, writes `?q=` (configurable) and
 * resets the page param. Keeps focus by replacing (not pushing) through the
 * wired ListNav router. Localized copy is supplied through props.
 */
export declare function SearchInput({ placeholder, searchLabel, clearLabel, paramKey, pageParamKey, className, }: {
    placeholder?: string;
    searchLabel?: string;
    clearLabel?: string;
    paramKey?: string;
    /** Pagination param to reset when the search changes (sub-tables use prefixed params). */
    pageParamKey?: string;
    className?: string;
}): React.JSX.Element;
//# sourceMappingURL=list-search-input.d.ts.map