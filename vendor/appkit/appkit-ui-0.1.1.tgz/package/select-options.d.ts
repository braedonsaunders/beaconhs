import * as React from 'react';
import type { SelectOption } from './search-select.js';
type ParsedSelectChildren = {
    options: SelectOption[];
    placeholder?: string;
    clearable: boolean;
    emptyLabel?: string;
};
export declare function selectChildrenEqual(left: ParsedSelectChildren, right: ParsedSelectChildren): boolean;
/** Read the resolved option tree after React components have rendered inside
 * the hidden native select. This covers option-producing components, which
 * cannot be evaluated safely while parsing the original ReactNode tree. */
export declare function parseNativeSelect(select: HTMLSelectElement): ParsedSelectChildren;
export declare function parseSelectChildren(children: React.ReactNode): ParsedSelectChildren;
export {};
//# sourceMappingURL=select-options.d.ts.map