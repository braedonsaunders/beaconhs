import * as React from 'react';
import { type SidebarNavGroup } from './sidebar-nav.js';
import type { LinkRender } from './settings-layout.js';
/** Native-style mobile bottom bar driven by the shared navigation registry. */
export declare function MobileTabBar({ groups, pathname, onOpenMenu, linkRender, tabCount, menuLabel, ariaLabel, }: {
    groups: SidebarNavGroup[];
    pathname: string;
    onOpenMenu: () => void;
    linkRender?: LinkRender;
    tabCount?: number;
    menuLabel?: string;
    ariaLabel?: string;
}): React.JSX.Element | null;
//# sourceMappingURL=mobile-tab-bar.d.ts.map