import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
export function EmptyState({ icon, title, description, action, className }) {
    return (_jsxs("div", { className: cn('reveal flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-bg-subtle px-8 py-14 text-center', className), children: [icon ? (_jsx("div", { className: "mb-5 flex size-14 items-center justify-center rounded-2xl bg-surface text-fg-subtle shadow-sm ring-1 ring-border [&_svg]:size-7", children: icon })) : null, _jsx("h3", { className: "text-base font-semibold text-fg", children: title }), description ? (_jsx("p", { className: "mt-1.5 max-w-md text-sm leading-relaxed text-fg-muted", children: description })) : null, action ? _jsx("div", { className: "mt-5", children: action }) : null] }));
}
//# sourceMappingURL=empty-state.js.map