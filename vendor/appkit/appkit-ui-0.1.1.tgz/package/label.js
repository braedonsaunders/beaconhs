import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
import { cn } from './utils.js';
export const Label = React.forwardRef(({ className, ...props }, ref) => (_jsx("label", { ref: ref, className: cn('text-sm font-medium leading-none text-fg peer-disabled:cursor-not-allowed peer-disabled:opacity-70', className), ...props })));
Label.displayName = 'Label';
//# sourceMappingURL=label.js.map