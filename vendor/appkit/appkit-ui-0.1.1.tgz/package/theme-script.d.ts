/** Script body for a framework's pre-hydration script facility (for example next/script). */
export declare function getThemeScript(storageKey?: string): string;
//# sourceMappingURL=theme-script.d.ts.map