import * as React from 'react';
export interface PageTransitionProps {
    /** A stable value that changes when the routed page changes, usually usePathname(). */
    navigationKey: React.Key;
    children: React.ReactNode;
    className?: string;
}
/**
 * Keeps the application shell live while the browser hands the changing page
 * canvas between routes. Requires Next.js `experimental.viewTransition`.
 */
export declare function PageTransition({ navigationKey, children, className, }: PageTransitionProps): React.JSX.Element;
//# sourceMappingURL=page-transition.d.ts.map