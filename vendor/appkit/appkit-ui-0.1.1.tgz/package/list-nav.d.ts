import * as React from 'react';
/**
 * Router bridge for the URL-driven list kit (SearchInput, FilterChips,
 * SortableTh, Pagination). The query string is the canonical list state, so
 * these components navigate. An app wires its client router once:
 *
 *   <ListNavProvider value={{ pathname, search, replace: (h) => router.replace(h, { scroll: false }), push: (h) => router.push(h, { scroll: false }) }}>
 *
 * Without a provider the components fall back to full navigations via
 * window.location — correct everywhere, just not soft.
 */
export type ListNav = {
    pathname: string;
    /** Current query string WITHOUT the leading `?`. */
    search: string;
    replace: (href: string) => void;
    push: (href: string) => void;
};
export declare function ListNavProvider({ value, children }: {
    value: ListNav;
    children: React.ReactNode;
}): React.JSX.Element;
/** The wired router, or a window-backed fallback (null during SSR). */
export declare function useListNav(): ListNav | null;
/** Anchor click handler: soft-navigate through the wired router when the click
 *  is a plain left-click (no modifiers), else let the browser handle it. */
export declare function useListNavClick(href: string): (e: React.MouseEvent<HTMLAnchorElement>) => void;
//# sourceMappingURL=list-nav.d.ts.map