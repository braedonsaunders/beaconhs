export type ListParams<S extends string = string> = {
    q: string | undefined;
    sort: S;
    dir: 'asc' | 'desc';
    page: number;
    perPage: number;
};
export type ListSearchParams = Record<string, string | string[] | undefined>;
/**
 * True when `value` is a UUID. Use to guard `[id]` route params before querying
 * a uuid PK — a non-UUID segment otherwise throws a Postgres "invalid input
 * syntax for type uuid" error instead of a clean 404.
 */
export declare function isUuid(value: string): boolean;
export declare function parseListParams<S extends string>(searchParams: ListSearchParams, config: {
    sort: S;
    dir?: 'asc' | 'desc';
    perPage?: number;
    allowedSorts: readonly S[];
}): ListParams<S>;
/**
 * Parse a list that shares its route with other independently paged lists.
 * `prefix="review"` reads reviewQ/reviewSort/reviewDir/reviewPage/reviewPerPage,
 * keeping one sub-list's controls from resetting another one.
 */
export declare function parsePrefixedListParams<S extends string>(searchParams: ListSearchParams, prefix: string, config: {
    sort: S;
    dir?: 'asc' | 'desc';
    perPage?: number;
    allowedSorts: readonly S[];
}): ListParams<S>;
export declare function pickString(v: string | string[] | undefined): string | undefined;
export declare function clamp(n: number, min: number, max: number): number;
export declare function buildHref(base: string, params: Record<string, string | number | undefined | null>): string;
export declare function mergeHref(base: string, current: ListSearchParams, overrides: Record<string, string | number | undefined | null>): string;
/**
 * Build an export URL that carries the current list filters but drops
 * pagination params (export is always "all visible rows that match").
 */
export declare function buildExportHref(base: string, current: ListSearchParams): string;
//# sourceMappingURL=list-params.d.ts.map