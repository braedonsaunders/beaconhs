import * as React from 'react';
export type EmptyStateProps = {
    icon?: React.ReactNode;
    title: string;
    description?: string;
    action?: React.ReactNode;
    className?: string;
};
export declare function EmptyState({ icon, title, description, action, className }: EmptyStateProps): React.JSX.Element;
//# sourceMappingURL=empty-state.d.ts.map