import * as React from 'react';
export type SeparatorProps = React.HTMLAttributes<HTMLDivElement> & {
    orientation?: 'horizontal' | 'vertical';
};
export declare function Separator({ className, orientation, ...props }: SeparatorProps): React.JSX.Element;
//# sourceMappingURL=separator.d.ts.map