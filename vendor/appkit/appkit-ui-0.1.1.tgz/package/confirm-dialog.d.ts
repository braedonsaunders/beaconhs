import * as React from 'react';
export type ConfirmTone = 'default' | 'danger';
export type ConfirmDialogOptions = {
    title?: string;
    message: React.ReactNode;
    confirmLabel?: string;
    cancelLabel?: string;
    tone?: ConfirmTone;
};
/** Promise-based, application-wide replacement for `window.confirm()`. */
export declare function confirmDialog(options: string | ConfirmDialogOptions): Promise<boolean>;
export declare function cancelConfirmDialog(): void;
export type ConfirmRootProps = {
    labels?: {
        defaultTitle?: string;
        dangerTitle?: string;
        confirm?: string;
        cancel?: string;
    };
};
/** Mount once near the root of an application that calls `confirmDialog`. */
export declare function ConfirmRoot({ labels }: ConfirmRootProps): React.ReactPortal | null;
//# sourceMappingURL=confirm-dialog.d.ts.map