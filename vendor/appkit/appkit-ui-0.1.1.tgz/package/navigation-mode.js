'use client';
import { jsx as _jsx } from "react/jsx-runtime";
import * as React from 'react';
const NavigationModeContext = React.createContext(null);
export function NavigationModeProvider({ children, defaultMode = 'topbar', cookieName = 'appkit-navigation-mode', onChange, }) {
    const [mode, setModeState] = React.useState(defaultMode);
    const [mounted, setMounted] = React.useState(false);
    React.useEffect(() => {
        const stored = document.cookie
            .split('; ')
            .find((entry) => entry.startsWith(`${encodeURIComponent(cookieName)}=`))
            ?.slice(encodeURIComponent(cookieName).length + 1);
        if (stored === 'topbar' || stored === 'sidebar')
            setModeState(stored);
        setMounted(true);
    }, [cookieName]);
    const setMode = React.useCallback((next) => {
        setModeState(next);
        document.cookie = `${encodeURIComponent(cookieName)}=${next};path=/;max-age=31536000;samesite=lax`;
        void onChange?.(next);
    }, [cookieName, onChange]);
    return (_jsx(NavigationModeContext.Provider, { value: { mode, setMode, mounted }, children: children }));
}
export function useNavigationMode() {
    const context = React.useContext(NavigationModeContext);
    if (!context)
        throw new Error('useNavigationMode must be used within NavigationModeProvider');
    return context;
}
//# sourceMappingURL=navigation-mode.js.map