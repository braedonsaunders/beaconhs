import * as React from 'react';
export type Theme = 'light' | 'dark' | 'system';
export type ResolvedTheme = 'light' | 'dark';
type ThemeContextValue = {
    theme: Theme;
    resolvedTheme: ResolvedTheme;
    setTheme: (theme: Theme) => void;
    mounted: boolean;
};
export declare function ThemeProvider({ children, storageKey, }: {
    children: React.ReactNode;
    storageKey?: string;
}): React.JSX.Element;
export declare function useTheme(): ThemeContextValue;
export type ThemeToggleLabels = {
    label: string;
    light: string;
    system: string;
    dark: string;
    current: (theme: string) => string;
};
export declare function ThemeToggle({ collapsed, labels, className, }: {
    collapsed?: boolean;
    labels?: ThemeToggleLabels;
    className?: string;
}): React.JSX.Element;
export {};
//# sourceMappingURL=theme.d.ts.map