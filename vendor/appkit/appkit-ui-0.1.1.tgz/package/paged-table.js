'use client';
import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import * as React from 'react';
import { Button } from './button.js';
import { Input } from './input.js';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, } from './table.js';
const DEFAULT_LABELS = {
    searchPlaceholder: 'Search…',
    searchLabel: 'Search',
    showing: (from, to, total) => _jsxs(_Fragment, { children: ["Showing ", _jsx("strong", { className: "font-semibold text-fg", children: from }), "\u2013", _jsx("strong", { className: "font-semibold text-fg", children: to }), " of", ' ', _jsx("strong", { className: "font-semibold text-fg", children: total })] }),
    prev: 'Prev',
    next: 'Next',
    pageOf: (page, pages) => _jsxs(_Fragment, { children: ["Page ", page, " of ", pages] }),
};
/**
 * Client-side searched and paginated table for bounded data already loaded
 * into a page or drawer. The call surface matches the production reference;
 * only localized copy and semantic tokens are injected/generalized.
 */
export function PagedTable({ rows, columns, pageSize = 10, searchable = false, empty, rowKey, rowClassName, labels: labelOverrides, }) {
    const labels = { ...DEFAULT_LABELS, ...labelOverrides };
    const [query, setQuery] = React.useState('');
    const [page, setPage] = React.useState(0);
    const filtered = React.useMemo(() => {
        const normalized = query.trim().toLocaleLowerCase();
        if (!normalized)
            return rows;
        return rows.filter((row) => columns.some((column) => column.search?.(row).toLocaleLowerCase().includes(normalized)));
    }, [columns, query, rows]);
    const boundedPageSize = Math.max(1, Math.trunc(pageSize));
    const pageCount = Math.max(1, Math.ceil(filtered.length / boundedPageSize));
    const clamped = Math.min(page, pageCount - 1);
    const start = clamped * boundedPageSize;
    const visible = filtered.slice(start, start + boundedPageSize);
    if (rows.length === 0)
        return _jsx(_Fragment, { children: empty });
    return _jsxs("div", { className: "space-y-3", children: [searchable ? _jsx(Input, { type: "search", "aria-label": labels.searchLabel, value: query, onChange: (event) => {
                    setQuery(event.target.value);
                    setPage(0);
                }, placeholder: labels.searchPlaceholder, className: "max-w-xs" }) : null, _jsxs(Table, { children: [_jsx(TableHeader, { children: _jsx(TableRow, { noAnimate: true, children: columns.map((column) => _jsx(TableHead, { align: column.align === 'right' ? 'right' : undefined, className: column.align === 'right' ? 'text-right' : undefined, children: column.header }, column.key)) }) }), _jsx(TableBody, { children: visible.map((row, index) => _jsx(TableRow, { className: rowClassName?.(row), children: columns.map((column) => _jsx(TableCell, { className: column.align === 'right' ? 'text-right tabular-nums' : undefined, children: column.cell(row) }, column.key)) }, rowKey(row, start + index))) })] }), filtered.length > boundedPageSize ? _jsxs("div", { className: "flex items-center justify-between text-xs text-fg-muted", children: [_jsx("span", { children: labels.showing(start + 1, Math.min(start + boundedPageSize, filtered.length), filtered.length) }), _jsxs("div", { className: "flex items-center gap-1.5", children: [_jsx(Button, { variant: "outline", size: "sm", disabled: clamped === 0, onClick: () => setPage(clamped - 1), children: labels.prev }), _jsx("span", { className: "tabular-nums", children: labels.pageOf(clamped + 1, pageCount) }), _jsx(Button, { variant: "outline", size: "sm", disabled: clamped >= pageCount - 1, onClick: () => setPage(clamped + 1), children: labels.next })] })] }) : null] });
}
//# sourceMappingURL=paged-table.js.map