import * as React from 'react';
export type InputProps = React.InputHTMLAttributes<HTMLInputElement>;
/**
 * Input — tokenized field. `text-base` under sm: keeps iOS Safari from zooming
 * the viewport on focus (anything under 16px triggers it). `aria-invalid`
 * drives the error styling, so validation is a single attribute away.
 */
export declare const Input: React.ForwardRefExoticComponent<InputProps & React.RefAttributes<HTMLInputElement>>;
//# sourceMappingURL=input.d.ts.map